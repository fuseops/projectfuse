<?php
// created: 2009-09-10 12:14:04
$mod_strings = array (
  'LBL_SEND_SMS' => 'Send SMS',
  
);
?>

<?php 
 //WARNING: The contents of this file are auto-generated


// created: 2009-08-13 13:22:29
$dictionary["Campaign"]["fields"]["campaigns_sms_sms"] = array (
  'name' => 'campaigns_sms_sms',
  'type' => 'link',
  'relationship' => 'campaigns_sms_sms',
  'source' => 'non-db',
);


?>
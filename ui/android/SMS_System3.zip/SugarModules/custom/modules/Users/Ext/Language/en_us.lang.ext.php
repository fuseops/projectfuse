<?php 
 //WARNING: The contents of this file are auto-generated


/*****************************************************************************
 * Language file
 ********************************************************************************/
$mod_strings['LBL_SMS_SETTINGS'] = 'SMS Settings';
$mod_strings['LBL_SMSURL'] = 'SMS Url:';
$mod_strings['LBL_SMSAPIKEY'] = 'SMS APIKey:';
$mod_strings['LBL_SMSAPIPASSWORD'] = 'SMS API Password:';

?>
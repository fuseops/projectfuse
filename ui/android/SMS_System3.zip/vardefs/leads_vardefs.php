<?php
// created: 2009-08-13 13:22:29
$dictionary["Lead"]["fields"]["leads_sms_sms"] = array (
  'name' => 'leads_sms_sms',
  'type' => 'link',
  'relationship' => 'leads_sms_sms',
  'source' => 'non-db',
);
?>

<?php
// created: 2009-08-13 13:22:29
$dictionary["Contact"]["fields"]["contacts_sms_sms"] = array (
  'name' => 'contacts_sms_sms',
  'type' => 'link',
  'relationship' => 'contacts_sms_sms',
  'source' => 'non-db',
);
?>

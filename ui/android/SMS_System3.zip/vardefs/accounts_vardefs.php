<?php
// created: 2009-08-13 13:22:29
$dictionary["Account"]["fields"]["accounts_sms_sms"] = array (
  'name' => 'accounts_sms_sms',
  'type' => 'link',
  'relationship' => 'accounts_sms_sms',
  'source' => 'non-db',
);
?>
